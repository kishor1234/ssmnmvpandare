
<style>
    .btn-custom-black{
        background-color: #000;
        border-color: #000;
        color:#FFF;
    }
</style>

<div class="section3_bottom_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-md-10 col-xs-10 col-sm-10">
                <div class="section3_copyright">
                    <p>Copyright 2018 <a href="/">  Tahaan Pest Solution </a>. all right reserved - design by <a href="http://aasksoft.co.in/">@askSoft</a></p>
<!--                    <p class="footer">Memory Useage in <strong>{memory_usage}</strong>Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo (ENVIRONMENT === 'development') ? 'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>-->
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-xs-2 col-sm-2">
                <div class="close_wrapper">

                    <a href="javascript:" id="return-to-top"><i class="fa fa-arrow-up"></i>top</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

<script src="assets/html/js/owl.carousel.js"></script>

<script src="assets/html/js/custom.js"></script>

</body>
</html>