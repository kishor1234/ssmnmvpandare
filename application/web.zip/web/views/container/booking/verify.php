<style>
    .h3{
        font-size: 60px;
        line-height: normal;
        color: #db0;
    }
    .h2{
        font-size: 60px;
        line-height: normal;
    }
</style>
<section id="thankyou" class="bg-gray-light clearfix" style="margin: 150px auto;">
    <div class="container">
        <div class="row">
            <div class="thankscontent text-center" data-aos="fade-down">
                <h3 class="h3"><i class="fa fa-check"></i></h3>
                <h2 class="h2">Thank You!</h2>
                <p class="mb-30"><?= $msg ?></p>
                <a href="https://www.tahaanpestsolutions.com/" class="appint-btn hidden-xs hidden-sm">

                    <div class="btn-front"><i class="fa fa-home"></i> Back To Homepage</div>
                    <div class="btn-back"><i class="fa fa-home"></i> Back To Homepage</div>
                </a>
            </div>

        </div>
    </div>
</section>