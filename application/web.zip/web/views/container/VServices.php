<?php
$main->isLoadView("banner", false, array("title" => "Our Services"));
?>
<div class="sp_choose_main_wrapper" id="web">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12 col-lg-offset-2">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder50">
                    <h2><span>Our Services</span></h2>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="sp_choose_main_wrapper white"  id="mobile">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12 col-lg-offset-2">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder50">
                    <h2><span>Our Services</span></h2>
                </div>
            </div>

        </div>
    </div>
</div>
<?php
$main->isLoadView("VServicesSesction", false, array());
?>


