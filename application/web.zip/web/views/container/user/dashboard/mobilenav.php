<li class='has-sub open'><a href='#'>User</a>
    <ul style="display: block;">
        <li><a href="/profile"> Profile</a>
        </li>
        <li><a href="/changepassword"> Change Password</a>
        </li>
        <li><a href="/myorder"> My Order's</a>
        </li>
        <li><a href="/logout"> Logout</a>
        </li>
    </ul>
</li>