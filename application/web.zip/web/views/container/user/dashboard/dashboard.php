<section class="content-header">
    <h1>
        Dashboard
        <small>Booking Page</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Booking Page</li>
        <li class="active"><a href="/">Back to site</a></li>
    </ol>
</section>
<section class="content">
    <!-- Small boxes (Stat box) -->
    <style>
        .panel-primary {
            width: 70% !important;
            border-color: #337ab7;
        }
    </style>
    <?php
    $main->isLoadViewSp("userheader", "userfooter", "booking", false, array());
    ?>
</section>
