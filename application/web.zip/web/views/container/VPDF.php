<?php
$main->isLoadView("banner", false, array("title" => "PDF View"));
?>
<div class="sp_choose_main_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12 col-lg-offset-2">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder50">
                    <h2><span>Our Services</span></h2>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="service_page_section pst_toppadder100 pst_bottompadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                <div class="blog_wrapper_catt sidebar_widget">
                    <iframe src="https://docs.google.com/gview?url=https://path.com/to/your/pdf.pdf&embedded=true" style="width:600px; height:500px;" frameborder="0"></iframe>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">

                <?php $main->isLoadView("sidebar", false, array()); ?>
            </div>
        </div>
    </div>
    <!--service client section end-->


