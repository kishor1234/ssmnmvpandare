
<div class="about_us_sections serv_3_wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder10 pd" >
                    <h3 class="h3"><span>Viral Disinfestation Services for COVID-19</span></h3>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="o-video">
                    <iframe src="https://www.youtube.com/embed/oq8GOU02xa4?autoplay=0&controls=0&loop=1&playlist=oq8GOU02xa4&amp;showinfo=0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="o-video">
                    <iframe src="https://www.youtube.com/embed/19cKFHe1VUU?autoplay=0&controls=0&loop=1&playlist=19cKFHe1VUU&amp;showinfo=0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>