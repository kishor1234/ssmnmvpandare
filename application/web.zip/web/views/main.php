
<?php
//$main->isLoadView("VSlider", false, array());
//$main->isLoadView("homeBanner", false, array());
$main->isLoadView("bookingsnap", false, array());
$main->isLoadView("VHomInfo", false, array());
$main->isLoadView("VOurProcess", false, array());
$main->isLoadView("insta", false, array());
$main->isLoadView("PromVideo",false,array());
?>


<div class="sp_choose_main_wrapper web">
    <div class="container">
        <div class="row">

            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12 col-lg-offset-2">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder10">
                    <h3 class="h3"><span>Our Services</span></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sp_choose_main_wrapper white mobile" >
    <div class="container">
        <div class="row">

            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12 col-lg-offset-2">
                <div class="sp_choose_heading_main_wrapper pst_bottompadder10">
                    <h3 class="h3"><span>Our Services</span></h3>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$main->isLoadView("VServicesSesction", false, array());
$main->isLoadView("VWhyChoiseUs", false, array());
$main->isLoadView("VSnapBlog", false, array());
$main->isLoadView("VTestimonalis", false, array());
$main->isLoadView("VTopLocations", false, array());
$main->isLoadView("VAreaServed", false, array());
?>

